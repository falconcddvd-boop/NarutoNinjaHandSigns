# Obtener el APK usando solo el celular

Este proyecto todavía no contiene un APK compilado. El workflow de GitHub Actions incluido permite compilarlo en la nube, sin computadora propia.

1. Necesitás una cuenta gratuita de GitHub e iniciar sesión en github.com desde el celular.
2. Creá un repositorio nuevo y vacío llamado `NarutoNinjaHandSigns`.
3. Descomprimí este ZIP en el teléfono.
4. Desde el repositorio, usá **Add file → Upload files** y subí el contenido de la carpeta del proyecto, incluida la carpeta oculta `.github/workflows`.
5. Esperá a que termine la acción **Build Android APK** en la pestaña **Actions**.
6. Abrí la ejecución terminada y descargá el artefacto `Naruto-Ninja-Hand-Signs-debug-apk`.
7. Descomprimí el artefacto y tocá `app-debug.apk` para instalarlo. Android puede pedirte autorizar la instalación desde el navegador o administrador de archivos.

Si la carpeta `.github` no aparece al seleccionar archivos en Android, hay que activar la opción de mostrar archivos ocultos o usar el navegador/gestor de archivos que permita seleccionarla.

## Qué incluye esta compilación

Es la base inicial: menú, selector de dificultad y vista previa de cámara. El reconocimiento automático de las manos y la validación real de los sellos todavía no están implementados.
