# Naruto – Ninja Hand Signs (base Android 0.1)

Proyecto inicial Android Studio en Kotlin.

## Incluido
- Pantalla de inicio con estética naranja/negro/rojo.
- Selección de modo fácil (3 sellos) y difícil (6 sellos).
- Vista de cámara frontal usando CameraX.
- Flujo guiado de calibración de seis posiciones.

## Pendiente antes de considerarlo un juego funcional
- Integrar un modelo de detección de manos (landmarks) y seguimiento simultáneo de ambas manos.
- Capturar y guardar descriptores de cada pose durante la calibración.
- Comparar poses en orden, con tolerancia a diferencias de escala/posición.
- Implementar puntuación por precisión y tiempo, efectos y recursos visuales licenciados/originales.

La pantalla de cámara y los botones de avance son una base de interfaz: todavía no detectan ni validan automáticamente los sellos. No se distribuye como APK listo.

## Abrir
1. Descomprimir el ZIP.
2. Abrir la carpeta `NarutoNinjaHandSigns` desde Android Studio.
3. Esperar la sincronización de Gradle.
4. Ejecutar en un teléfono Android con cámara frontal.

Requisitos: Android Studio reciente, JDK 17 y SDK Android 35 instalados.
