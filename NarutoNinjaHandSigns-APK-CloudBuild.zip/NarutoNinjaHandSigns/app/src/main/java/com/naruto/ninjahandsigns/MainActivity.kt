package com.naruto.ninjahandsigns

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var cameraPreview: PreviewView
    private lateinit var status: TextView
    private var difficulty = "FÁCIL"
    private var currentSeal = 1
    private var calibrationMode = false

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else Toast.makeText(this, "Necesitamos permiso para usar la cámara", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun baseLayout(title: String, subtitle: String): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF111111.toInt())
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 30f
            setTextColor(0xFFFF6A00.toInt())
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val sub = TextView(this).apply {
            text = subtitle
            textSize = 14f
            setTextColor(0xFFFFD6B0.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        root.addView(heading, LinearLayout.LayoutParams(-1, -2))
        root.addView(sub, LinearLayout.LayoutParams(-1, -2))
        return root
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(0xFFB83218.toInt())
        textSize = 16f
        isAllCaps = false
        setOnClickListener { action() }
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, 8, 0, 8)
        layoutParams = p
    }

    private fun showHome() {
        val layout = baseLayout("忍 NINJA HAND SIGNS", "UN JUEGO DE SELLOS NINJA · EDICIÓN NARUTO")
        val hero = TextView(this).apply {
            text = "🔥\nKATON\nGŌKAKYŪ NO JUTSU\n\nDominá los sellos y liberá tu chakra."
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(12, 24, 12, 32)
        }
        layout.addView(hero, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(makeButton("EMPEZAR", ::showDifficulty))
        layout.addView(makeButton("CALIBRAR MIS SELLOS", ::showCalibrationIntro))
        layout.addView(TextView(this).apply {
            text = "Versión inicial 0.1 · Proyecto de prueba"
            setTextColor(0xFF888888.toInt()); textSize = 11f; gravity = Gravity.CENTER
            setPadding(0, 18, 0, 0)
        })
        setContentView(layout)
    }

    private fun showDifficulty() {
        val layout = baseLayout("ELEGÍ TU DESAFÍO", "KATON · BOLA DE FUEGO")
        layout.addView(makeButton("MODO FÁCIL · 3 SELLOS") { difficulty = "FÁCIL"; showGame() })
        layout.addView(makeButton("MODO DIFÍCIL · 6 SELLOS") { difficulty = "DIFÍCIL"; showGame() })
        layout.addView(makeButton("VOLVER") { showHome() })
        setContentView(layout)
    }

    private fun showCalibrationIntro() {
        val layout = baseLayout("CALIBRACIÓN", "REGISTRÁ TUS SEIS POSICIONES")
        val info = TextView(this).apply {
            text = "La app te va a mostrar una posición por vez. Colocá las dos manos frente a la cámara y guardá cada pose.\n\nEsto permite adaptar el reconocimiento a tus manos y a la forma en que hacés cada sello.\n\nEn esta primera entrega la cámara ya funciona; el reconocimiento automático de manos se incorpora en la siguiente etapa."
            textSize = 17f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
        }
        layout.addView(info, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(makeButton("ABRIR CÁMARA") { calibrationMode = true; currentSeal = 1; showCameraScreen() })
        layout.addView(makeButton("VOLVER") { showHome() })
        setContentView(layout)
    }

    private fun showGame() {
        currentSeal = 1
        calibrationMode = false
        showCameraScreen()
    }

    private fun showCameraScreen() {
        val layout = baseLayout(if (calibrationMode) "CALIBRAR SELLO" else "KATON · BOLA DE FUEGO", "MODO $difficulty")
        status = TextView(this).apply {
            text = if (calibrationMode) "Posición $currentSeal de 6 · Mostrá ambas manos" else "Sello $currentSeal de ${if (difficulty == "FÁCIL") 3 else 6} · Mostrá ambas manos"
            textSize = 17f; setTextColor(0xFFFFD6B0.toInt()); gravity = Gravity.CENTER
            setPadding(0, 4, 0, 12)
        }
        layout.addView(status)
        cameraPreview = PreviewView(this).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
        layout.addView(cameraPreview, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(makeButton(if (calibrationMode) "GUARDAR POSE Y CONTINUAR" else "SIGUIENTE SELLO") {
            val total = if (calibrationMode) 6 else if (difficulty == "FÁCIL") 3 else 6
            if (currentSeal < total) {
                currentSeal++
                status.text = if (calibrationMode) "Posición $currentSeal de 6 · Mostrá ambas manos" else "Sello $currentSeal de $total · Mostrá ambas manos"
            } else {
                Toast.makeText(this, if (calibrationMode) "Calibración guiada completada (guardado automático pendiente)" else "¡Secuencia completada!", Toast.LENGTH_LONG).show()
                showHome()
            }
        })
        layout.addView(makeButton("SALIR") { showHome() })
        setContentView(layout)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(cameraPreview.surfaceProvider) }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview)
            } catch (e: Exception) {
                Toast.makeText(this, "No se pudo iniciar la cámara: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }
}
